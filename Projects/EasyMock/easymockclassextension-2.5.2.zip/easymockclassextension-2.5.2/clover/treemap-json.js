processTreeMapJson (  {"id":"Clover database dim. déc. 20 2009 21:32:03 CET0","name":"","data":{
    "$area":606.0,"$color":100.0,"title":" 606 Elements, 100% Coverage"},
  "children":[{"id":"org.easymock.classextension.internal179","name":
      "org.easymock.classextension.internal","data":{"$area":428.0,"$color":
        100.0,"title":
        "org.easymock.classextension.internal 428 Elements, 100% Coverage"},
      "children":[{"id":"BridgeMethodResolver179","name":
          "BridgeMethodResolver","data":{"$area":0.0,"$color":-100.0,"path":
            "org/easymock/classextension/internal/BridgeMethodResolver.html#BridgeMethodResolver",
            "title":"BridgeMethodResolver 0 Elements,  -  Coverage"},
          "children":[]},{"id":"ClassExtensionHelper456","name":
          "ClassExtensionHelper","data":{"$area":21.0,"$color":100.0,"path":
            "org/easymock/classextension/internal/ClassExtensionHelper.html#ClassExtensionHelper",
            "title":"ClassExtensionHelper 21 Elements, 100% Coverage"},
          "children":[]},{"id":"ClassInstantiatorFactory478","name":
          "ClassInstantiatorFactory","data":{"$area":12.0,"$color":100.0,
            "path":
            "org/easymock/classextension/internal/ClassInstantiatorFactory.html#ClassInstantiatorFactory",
            "title":"ClassInstantiatorFactory 12 Elements, 100% Coverage"},
          "children":[]},{"id":"ClassProxyFactory491","name":
          "ClassProxyFactory","data":{"$area":43.0,"$color":100.0,"path":
            "org/easymock/classextension/internal/ClassProxyFactory.html#ClassProxyFactory",
            "title":"ClassProxyFactory 43 Elements, 100% Coverage"},
          "children":[]},{"id":
          "ClassProxyFactory.MockMethodInterceptor491","name":
          "ClassProxyFactory.MockMethodInterceptor","data":{"$area":53.0,
            "$color":100.0,"path":
            "org/easymock/classextension/internal/ClassProxyFactory.html#ClassProxyFactory.MockMethodInterceptor",
            "title":
            "ClassProxyFactory.MockMethodInterceptor 53 Elements, 100% Coverage"},
          "children":[]},{"id":"DefaultClassInstantiator598","name":
          "DefaultClassInstantiator","data":{"$area":68.0,"$color":100.0,
            "path":
            "org/easymock/classextension/internal/DefaultClassInstantiator.html#DefaultClassInstantiator",
            "title":"DefaultClassInstantiator 68 Elements, 100% Coverage"},
          "children":[]},{"id":"IClassInstantiator685","name":
          "IClassInstantiator","data":{"$area":0.0,"$color":-100.0,"path":
            "org/easymock/classextension/internal/IClassInstantiator.html#IClassInstantiator",
            "title":"IClassInstantiator 0 Elements,  -  Coverage"},
          "children":[]},{"id":"MockBuilder685","name":"MockBuilder","data":{
            "$area":110.0,"$color":100.0,"path":
            "org/easymock/classextension/internal/MockBuilder.html#MockBuilder",
            "title":"MockBuilder 110 Elements, 100% Coverage"},"children":[]},
        {"id":"MocksClassControl795","name":"MocksClassControl","data":{
            "$area":34.0,"$color":100.0,"path":
            "org/easymock/classextension/internal/MocksClassControl.html#MocksClassControl",
            "title":"MocksClassControl 34 Elements, 100% Coverage"},
          "children":[]},{"id":"ObjenesisClassInstantiator829","name":
          "ObjenesisClassInstantiator","data":{"$area":2.0,"$color":100.0,
            "path":
            "org/easymock/classextension/internal/ObjenesisClassInstantiator.html#ObjenesisClassInstantiator",
            "title":"ObjenesisClassInstantiator 2 Elements, 100% Coverage"},
          "children":[]},{"id":"ReflectionUtils831","name":
          "ReflectionUtils","data":{"$area":85.0,"$color":100.0,"path":
            "org/easymock/classextension/internal/ReflectionUtils.html#ReflectionUtils",
            "title":"ReflectionUtils 85 Elements, 100% Coverage"},"children":
          []}]},{"id":"org.easymock.classextension0","name":
      "org.easymock.classextension","data":{"$area":178.0,"$color":100.0,
        "title":"org.easymock.classextension 178 Elements, 100% Coverage"},
      "children":[{"id":"ConstructorArgs0","name":"ConstructorArgs","data":{
            "$area":45.0,"$color":100.0,"path":
            "org/easymock/classextension/ConstructorArgs.html#ConstructorArgs",
            "title":"ConstructorArgs 45 Elements, 100% Coverage"},"children":
          []},{"id":"EasyMock45","name":"EasyMock","data":{"$area":66.0,
            "$color":100.0,"path":
            "org/easymock/classextension/EasyMock.html#EasyMock","title":
            "EasyMock 66 Elements, 100% Coverage"},"children":[]},{"id":
          "EasyMockSupport112","name":"EasyMockSupport","data":{"$area":
            38.0,"$color":100.0,"path":
            "org/easymock/classextension/EasyMockSupport.html#EasyMockSupport",
            "title":"EasyMockSupport 38 Elements, 100% Coverage"},"children":
          []},{"id":"IMockBuilder150","name":"IMockBuilder","data":{"$area":
            0.0,"$color":-100.0,"path":
            "org/easymock/classextension/IMockBuilder.html#IMockBuilder",
            "title":"IMockBuilder 0 Elements,  -  Coverage"},"children":[]},{
          "id":"IMocksControl150","name":"IMocksControl","data":{"$area":
            0.0,"$color":-100.0,"path":
            "org/easymock/classextension/IMocksControl.html#IMocksControl",
            "title":"IMocksControl 0 Elements,  -  Coverage"},"children":[]},
        {"id":"MockClassControl150","name":"MockClassControl","data":{
            "$area":29.0,"$color":100.0,"path":
            "org/easymock/classextension/MockClassControl.html#MockClassControl",
            "title":"MockClassControl 29 Elements, 100% Coverage"},
          "children":[]}]}]}

 ); 