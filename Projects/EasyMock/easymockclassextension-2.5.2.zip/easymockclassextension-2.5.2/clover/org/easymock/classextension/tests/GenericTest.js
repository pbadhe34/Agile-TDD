var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":78,"id":1696,"methods":[{"el":48,"sc":5,"sl":41},{"el":77,"sc":5,"sl":70}],"name":"GenericTest","sl":29},{"el":33,"id":1696,"methods":[],"name":"GenericTest.C","sl":31},{"el":39,"id":1696,"methods":[{"el":38,"sc":9,"sl":36}],"name":"GenericTest.B","sl":35},{"el":56,"id":1704,"methods":[{"el":53,"sc":9,"sl":51}],"name":"GenericTest.AbstractFoo","sl":50},{"el":62,"id":1706,"methods":[{"el":61,"sc":9,"sl":59}],"name":"GenericTest.ConcreteFoo","sl":58}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_134":{"methods":[{"sl":70}],"name":"testPackageScope","pass":true,"statements":[{"sl":72},{"sl":73},{"sl":74},{"sl":75},{"sl":76}]},"test_136":{"methods":[{"sl":41}],"name":"testBridgeUnmocked","pass":true,"statements":[{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47}]},"test_298":{"methods":[{"sl":70}],"name":"testPackageScope","pass":true,"statements":[{"sl":72},{"sl":73},{"sl":74},{"sl":75},{"sl":76}]},"test_48":{"methods":[{"sl":41}],"name":"testBridgeUnmocked","pass":true,"statements":[{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [48, 136], [], [48, 136], [48, 136], [48, 136], [48, 136], [48, 136], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [134, 298], [], [134, 298], [134, 298], [134, 298], [134, 298], [134, 298], [], []]
