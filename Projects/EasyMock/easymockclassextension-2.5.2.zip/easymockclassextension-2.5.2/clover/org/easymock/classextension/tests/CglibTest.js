var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":70,"id":1590,"methods":[{"el":45,"sc":5,"sl":38},{"el":69,"sc":5,"sl":47},{"el":52,"sc":13,"sl":49}],"name":"CglibTest","sl":31}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_194":{"methods":[{"sl":38},{"sl":47}],"name":"test","pass":true,"statements":[{"sl":41},{"sl":42},{"sl":44},{"sl":48},{"sl":55},{"sl":56},{"sl":57},{"sl":59},{"sl":61},{"sl":63},{"sl":66},{"sl":68}]},"test_274":{"methods":[{"sl":38},{"sl":47}],"name":"test","pass":true,"statements":[{"sl":41},{"sl":42},{"sl":44},{"sl":48},{"sl":55},{"sl":56},{"sl":57},{"sl":59},{"sl":61},{"sl":63},{"sl":66},{"sl":68}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [194, 274], [], [], [194, 274], [194, 274], [], [194, 274], [], [], [194, 274], [194, 274], [], [], [], [], [], [], [194, 274], [194, 274], [194, 274], [], [194, 274], [], [194, 274], [], [194, 274], [], [], [194, 274], [], [194, 274], [], []]
