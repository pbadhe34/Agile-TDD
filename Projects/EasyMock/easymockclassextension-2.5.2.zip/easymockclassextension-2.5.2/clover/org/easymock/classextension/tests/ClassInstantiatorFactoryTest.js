var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":72,"id":1606,"methods":[{"el":35,"sc":5,"sl":33},{"el":39,"sc":5,"sl":37},{"el":46,"sc":5,"sl":41},{"el":55,"sc":5,"sl":48},{"el":65,"sc":5,"sl":57},{"el":71,"sc":5,"sl":67}],"name":"ClassInstantiatorFactoryTest","sl":31}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_142":{"methods":[{"sl":67}],"name":"getJVM","pass":true,"statements":[{"sl":69}]},"test_146":{"methods":[{"sl":41}],"name":"getInstantiator_Default","pass":true,"statements":[{"sl":43},{"sl":45}]},"test_200":{"methods":[{"sl":67}],"name":"getJVM","pass":true,"statements":[{"sl":69}]},"test_242":{"methods":[{"sl":41}],"name":"getInstantiator_Default","pass":true,"statements":[{"sl":43},{"sl":45}]},"test_245":{"methods":[{"sl":48}],"name":"getInstantiator_Overriden","pass":true,"statements":[{"sl":50},{"sl":52},{"sl":54}]},"test_250":{"methods":[{"sl":48}],"name":"getInstantiator_Overriden","pass":true,"statements":[{"sl":50},{"sl":52},{"sl":54}]},"test_317":{"methods":[{"sl":57}],"name":"getInstantiator_BackToDefault","pass":true,"statements":[{"sl":59},{"sl":61},{"sl":62},{"sl":64}]},"test_55":{"methods":[{"sl":57}],"name":"getInstantiator_BackToDefault","pass":true,"statements":[{"sl":59},{"sl":61},{"sl":62},{"sl":64}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [146, 242], [], [146, 242], [], [146, 242], [], [], [250, 245], [], [250, 245], [], [250, 245], [], [250, 245], [], [], [55, 317], [], [55, 317], [], [55, 317], [55, 317], [], [55, 317], [], [], [200, 142], [], [200, 142], [], [], []]
