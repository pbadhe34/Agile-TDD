processTreeMapDashJson (  {"id":"Clover database dim. déc. 20 2009 21:32:03 CET0","name":"","data":{
    "$area":1563.0,"$color":94.30582,"title":
    " 1563 Elements, 94,3% Coverage"},"children":[{"id":
      "org.easymock.classextension.internal179","name":
      "org.easymock.classextension.internal","data":{"$area":428.0,"$color":
        100.0,"title":
        "org.easymock.classextension.internal 428 Elements, 100% Coverage"},
      "children":[]},{"id":"org.easymock.classextension0","name":
      "org.easymock.classextension","data":{"$area":178.0,"$color":100.0,
        "title":"org.easymock.classextension 178 Elements, 100% Coverage"},
      "children":[]},{"id":"org.easymock.classextension.tests1590","name":
      "org.easymock.classextension.tests","data":{"$area":284.0,"$color":
        86.61972,"title":
        "org.easymock.classextension.tests 284 Elements, 86,6% Coverage"},
      "children":[]},{"id":"org.easymock.classextension.tests2917","name":
      "org.easymock.classextension.tests2","data":{"$area":673.0,"$color":
        92.42199,"title":
        "org.easymock.classextension.tests2 673 Elements, 92,4% Coverage"},
      "children":[]}]}

 ); 